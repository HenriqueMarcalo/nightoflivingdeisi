package pt.ulusofona.lp2.thenightofthelivingdeisi.humanos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;

import java.util.ArrayList;

public class HumanoAdulto extends Humano {
    public HumanoAdulto(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 1, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Adulto";
    }

    @Override
    public boolean podeUsar(Equipamento equipamento) {
        return true; // Pode usar qualquer equipamento
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);

        if ((deltaX == 0 && deltaY <= 2) || (deltaY == 0 && deltaX <= 2)) {
            return true;
        }

        if (deltaX == deltaY && deltaX <= 2) {
            return true;
        }

        return false;
    }

    @Override
    public int getTipoZombie() {
        return 1; // tipo do ZombieAdulto
    }

    @Override
    public boolean podeSerTransformado() {
        return true;
    }

    @Override
    public boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos) {
        if (equipamento != null && podeUsar(equipamento)) {
            // Se já tem um equipamento, deixa na posição original antes de pegar o novo
            if (getEquipamento() != null) {
                Equipamento equipamentoAtual = getEquipamento();
                equipamentos.add(equipamentoAtual); // este é oq dropa
                equipamentoAtual.setCapturado(false);
                setEquipamento(null);
                posOrigem.setEquipamento(equipamentoAtual);
            }
            // Pega o novo equipamento
            equipamento.setCapturado(true);
            setEquipamento(equipamento);
            posDestino.setEquipamento(null);
            equipamentos.remove(equipamento);
            return true;
        }
        return false;
    }

    @Override
    public String getCreatureInfoAsString() {
        String info;
        if (isInSafeHaven()) {
            info = getId() + " | Adulto | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ Safe Haven";
        } else {
            info = getId() + " | Adulto | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ (" + getX() + ", " + getY() + ")";
        }
        if (getEquipamento() != null) {
            info += " | " + getEquipamento().getEquipmentInfoAsString();
        }
        return info;
    }
}