package pt.ulusofona.lp2.thenightofthelivingdeisi.humanos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;

import java.util.ArrayList;

public class HumanoCrianca extends Humano {
    public HumanoCrianca(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 0, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Criança";
    }

    @Override
    public boolean podeUsar(Equipamento equipamento) {
        return equipamento.getTipo() == 0 || equipamento.getTipo() == 3; // Só defensivos
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);

        // Verifica se há equipamento ofensivo no destino
        Posicao posDestino = tabuleiro.getPosicao(xDestino, yDestino);
        Equipamento equipamentoDestino = posDestino.getEquipamento();
        if (equipamentoDestino != null && !podeUsar(equipamentoDestino)) {
            return false;
        }

        return deltaX + deltaY == 1;
    }

    @Override
    public boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos) {
        if (equipamento != null && podeUsar(equipamento)) {
            // Se já tem um equipamento, deixa na posição original antes de pegar o novo
            if (getEquipamento() != null) {
                Equipamento equipamentoAtual = getEquipamento();
                equipamentos.add(equipamentoAtual); // este é oq dropa
                equipamentoAtual.setCapturado(false);
                setEquipamento(null);
                posOrigem.setEquipamento(equipamentoAtual);
            }
            // Pega o novo equipamento se for defensivo
            equipamento.setCapturado(true);
            setEquipamento(equipamento);
            posDestino.setEquipamento(null);
            equipamentos.remove(equipamento);
            return true;
        }
        return false;
    }

    @Override
    public int getTipoZombie() {
        return 0; // tipo do ZombieCrianca
    }

    @Override
    public boolean podeSerTransformado() {
        return true;
    }

    @Override
    public String getCreatureInfoAsString() {
        String info;
        if (isInSafeHaven()) {
            info = getId() + " | Criança | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ Safe Haven";
        } else {
            info = getId() + " | Criança | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ (" + getX() + ", " + getY() + ")";
        }
        if (getEquipamento() != null) {
            info += " | " + getEquipamento().getEquipmentInfoAsString();
        }
        return info;
    }
}