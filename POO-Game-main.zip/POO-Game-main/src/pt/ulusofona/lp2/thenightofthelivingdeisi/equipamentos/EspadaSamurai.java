package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Ofensivo;

public class EspadaSamurai extends Ofensivo {
    public EspadaSamurai(int id, int x, int y) {
        super(id, 1, x, y);
    }

    @Override
    public String getEquipmentInfoAsString() {
        return getId() + " | Espada samurai @ (" + getX() + ", " + getY() + ")";
    }
}