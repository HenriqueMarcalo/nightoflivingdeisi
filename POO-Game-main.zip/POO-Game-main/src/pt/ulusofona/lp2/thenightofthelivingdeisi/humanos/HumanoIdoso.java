package pt.ulusofona.lp2.thenightofthelivingdeisi.humanos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;

import java.util.ArrayList;

public class HumanoIdoso extends Humano {

    private int equipamentoOriginalX;
    private int equipamentoOriginalY;

    public HumanoIdoso(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 2, nome, x, y);
        this.equipamentoOriginalX = -1; // troquei estes dois para ver se inicializarmos logo sem equipamento se da pq o metodo set la em baixo ja trata de se ele apanhar
        this.equipamentoOriginalY = -1;
    }

    @Override
    public String getTipoCriatura() {
        return "Idoso";
    }

    @Override
    public boolean podeUsar(Equipamento equipamento) {
        return true;
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        if (!tabuleiro.isDay()) {
            return false;
        }
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);
        return deltaX == 1 && deltaY == 1;
    }

    @Override
    public void executarMovimento(int novoX, int novoY, Posicao origem, Posicao destino) {
        // Se está se movendo para uma posição sem equipamento, desequipa
        if (destino.getEquipamento() == null) {
            setEquipamento(null);
        }

        // Move o idoso
        origem.setHumano(null);
        destino.setHumano(this);
        setX(novoX);
        setY(novoY);
        if (getEquipamento() != null) {
            getEquipamento().atualizarCoordenadas(novoX, novoY);
        }
    }

    @Override
    public void setEquipamento(Equipamento equipamento) {
        super.setEquipamento(equipamento);
        if (equipamento != null) {
            this.equipamentoOriginalX = equipamento.getX();
            this.equipamentoOriginalY = equipamento.getY();
        }
    }

    @Override
    public boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos) {
        if (equipamento != null && podeUsar(equipamento)) {
            equipamento.setCapturado(true);
            setEquipamento(equipamento);
            //equipamentos.remove(equipamento);
            return false;
        }
        return false;
    }

    @Override
    public int getTipoZombie() {
        return 2; // tipo do ZombieIdoso
    }

    @Override
    public boolean podeSerTransformado() {
        return true;
    }

    @Override
    public String getCreatureInfoAsString() {
        String info;
        if (isInSafeHaven()) {
            info = getId() + " | Idoso | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ Safe Haven";
        } else {
            info = getId() + " | Idoso | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ (" + getX() + ", " + getY() + ")";
        }
        if (getEquipamento() != null) {
            info += " | " + getEquipamento().getEquipmentInfoAsString();
        }
        return info;
    }
}