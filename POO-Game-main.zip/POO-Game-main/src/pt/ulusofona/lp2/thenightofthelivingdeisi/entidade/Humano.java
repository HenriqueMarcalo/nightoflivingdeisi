package pt.ulusofona.lp2.thenightofthelivingdeisi.entidade;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Entidade;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Humano extends Entidade {
    private String nome;
    private int teamId;
    private int tipoCriatura;
    private Equipamento equipamento;
    private int equipamentosAcumulados;
    private boolean inSafeHaven;
    protected ArrayList<Equipamento> equipCapturados;
    private boolean jaProcriou = false;

    public Humano(int id, int teamId, int tipoCriatura, String nome, int x, int y) {
        super(id, x, y);
        this.teamId = teamId;
        this.tipoCriatura = tipoCriatura;
        this.nome = nome;
        this.equipamento = null;
        this.equipamentosAcumulados = 0;
        this.inSafeHaven = false;
    }

    public boolean isInSafeHaven() {
        return inSafeHaven;
    }

    public void setInSafeHaven(boolean status) {
        this.inSafeHaven = status;
    }

    public String getNome() {
        return this.nome;
    }

    public boolean jaProcriou(){
        return jaProcriou;
    }

    public void setJaProcriou(boolean jaProcriou){
        this.jaProcriou = jaProcriou;
    }

    public abstract String getTipoCriatura();

    public String[] getCreatureInfo() {
        String[] info = new String[7];
        info[0] = String.valueOf(getId());
        info[1] = getTipoCriatura();
        info[2] = "Humano";
        info[3] = nome;
        if (inSafeHaven) {
            info[4] = null;
            info[5] = null;
        } else {
            info[4] = String.valueOf(getX());
            info[5] = String.valueOf(getY());
        }
        info[6] = determinarImagemPersonalizada();
        return info;
    }

    public abstract boolean podeUsar(Equipamento equipamento);

    public abstract String getCreatureInfoAsString();

    public boolean hasEquipment(int equipmentTypeId) {
        return this.equipamento != null && this.equipamento.getTipo() == equipmentTypeId;
    }

    public void setEquipamento(Equipamento equipamento) {
        this.equipamento = equipamento;
        if (equipamento != null) {
            equipamentosAcumulados++;
        }
    }

    public boolean podeIrSafeHeaven(){
        return true;
    }

    public int getEquipamentosAcumulados() {
        return equipamentosAcumulados;
    }

    public abstract boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos);

    public abstract boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro);

    public void executarMovimento(int xD, int yD, Posicao posOrigem, Posicao posDestino) {
        posOrigem.setHumano(null);
        posDestino.setHumano(this);
        setX(xD);
        setY(yD);

        if (getEquipamento() != null) {
            getEquipamento().atualizarCoordenadas(xD, yD);
        }
    }

    public Equipamento getEquipamento() {
        return this.equipamento;
    }

    public abstract int getTipoZombie(); // Cada tipo de humano sabe em que tipo de zombie se transforma

    public abstract boolean podeSerTransformado();

    private String determinarImagemPersonalizada() {
        switch (getTipoCriatura()) {
            case "Criança":
                return "fred.png";
            case "Adulto":
                return "palves.png";
            case "Idoso":
                return "joaobidao.png";
            case "Cão":
                return "doggy.png";
            case "Rambo":
                return "duartesnow.png";
            default:
                return null;
        }
    }
}
