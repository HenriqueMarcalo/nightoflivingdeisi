package pt.ulusofona.lp2.thenightofthelivingdeisi.entidade;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Entidade;

public abstract class Equipamento extends Entidade {
    private int tipo;
    protected boolean capturado;

    public Equipamento(int id, int tipo, int x, int y) {
        super(id, x, y);
        this.tipo = tipo;
        this.capturado = false;
    }

    public void setCapturado(boolean capturado) {
        this.capturado = capturado;
    }

    public int getTipo() {
        return tipo;
    }

    public void atualizarCoordenadas(int x, int y) {
        setX(x);
        setY(y);
    }

    public String[] getEquipmentInfo() {
        String[] info = new String[5];
        info[0] = String.valueOf(getId());
        info[1] = String.valueOf(tipo);
        info[2] = String.valueOf(getX());
        info[3] = String.valueOf(getY());
        info[4] = determinarImagemEquipamentoPersonalizada();
        return info;
    }

    public abstract String getEquipmentInfoAsString();

    private String determinarImagemEquipamentoPersonalizada() {
        switch (getTipo()) {
            case 0:  return "benficaescudo.png";    // Escudo
            case 1:  return "spade.png";    // Espada
            case 2:  return "newfriend.png";           // Pistola
            case 3:  return "normal.png";           // Lixívia
            default: return null;
        }
    }

}

