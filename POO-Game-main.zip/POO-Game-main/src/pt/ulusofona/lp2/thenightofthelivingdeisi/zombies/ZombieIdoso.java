package pt.ulusofona.lp2.thenightofthelivingdeisi.zombies;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

public class ZombieIdoso extends Zombie {
    public ZombieIdoso(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 2, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Idoso";
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);
        return deltaX == 1 && deltaY == 1;
    }

    @Override
    public String getCreatureInfoAsString() {
        String txt = foiTransformado ? " (Transformado)" : "";
        return getId() + " | Idoso | Zombie" + txt + " | " + getNome() + " | -" + getEquipamentosDestruidos() + " @ (" + getX() + ", " + getY() + ")";
    }
}