package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Ofensivo;

public class Pistola extends Ofensivo {
    private int municao;

    public Pistola(int id, int x, int y) {
        super(id, 2, x, y);
        this.municao = 3;
    }

    public int getMunicao() {
        return municao;
    }

    public boolean usarPistola() {
        if (municao > 0) {
            municao--;
            return true;
        }
        return false;
    }

    @Override
    public String getEquipmentInfoAsString() {
        return getId() +
                " | Pistola Walther PPK @ (" + getX()
                + ", " + getY() + ")"
                + " | " + getMunicao() + " balas";
    }
}