package pt.ulusofona.lp2.thenightofthelivingdeisi;

import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Lixivia;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Pistola;
import pt.ulusofona.lp2.thenightofthelivingdeisi.factories.CriaturaFactory;
import pt.ulusofona.lp2.thenightofthelivingdeisi.factories.EquipamentoFactory;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.HumanoCrianca;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;
import java.io.IOException;
import java.util.List;


public class GameManager {

    private ArrayList<Humano> humanos = new ArrayList<>();
    private ArrayList<Zombie> zombies = new ArrayList<>();
    private ArrayList<Equipamento> equipamentos = new ArrayList<>();
    private ArrayList<Humano> humanosNoSafeHaven = new ArrayList<>();
    private Tabuleiro tabuleiro;
    private int jogadasInvalidasHumanos = 0;
    private int jogadasInvalidasZombies = 0;

    public GameManager() {
        this.humanos = new ArrayList<>();
        this.zombies = new ArrayList<>();
        this.equipamentos = new ArrayList<>();
        this.humanosNoSafeHaven = new ArrayList<>();
        this.tabuleiro = new Tabuleiro(0, 0);
        this.jogadasInvalidasHumanos = 0;
        this.jogadasInvalidasZombies = 0;
    }

    public void loadGame(File file) throws IOException, InvalidFileException {
        jogadasInvalidasZombies = 0;
        jogadasInvalidasHumanos = 0;
        humanos = new ArrayList<>();
        zombies = new ArrayList<>();
        equipamentos = new ArrayList<>();
        humanosNoSafeHaven = new ArrayList<>();
        try (Scanner scanner = new Scanner(file)) {
            int linhaAtual = 1;
            String[] dimensoes = scanner.nextLine().trim().split(" ");
            if (dimensoes.length != 2) {
                throw new InvalidFileException("Formato incorreto para as dimensões do tabuleiro", linhaAtual);
            }

            int largura = Integer.parseInt(dimensoes[0]);
            int altura = Integer.parseInt(dimensoes[1]);
            tabuleiro = new Tabuleiro(largura, altura);

            linhaAtual++;
            int initialTeamId = Integer.parseInt(scanner.nextLine().trim());
            tabuleiro.setInitialTeamId(initialTeamId);

            linhaAtual++;
            int numCriaturas = Integer.parseInt(scanner.nextLine().trim());
            for (int i = 0; i < numCriaturas; i++) {
                linhaAtual++;
                String[] criaturaInfo = scanner.nextLine().trim().split(" : ");
                int id = Integer.parseInt(criaturaInfo[0]);
                int teamId = Integer.parseInt(criaturaInfo[1]);
                int tipo = Integer.parseInt(criaturaInfo[2]);
                String nome = criaturaInfo[3];
                int x = Integer.parseInt(criaturaInfo[4]);
                int y = Integer.parseInt(criaturaInfo[5]);

                if (teamId == 20) {
                    Humano humano = (Humano) CriaturaFactory.createCreature(id, teamId, tipo, nome, x, y, linhaAtual);
                    humanos.add(humano);
                    tabuleiro.adicionarHumano(x, y, humano);
                } else if (teamId == 10) {
                    Zombie zombie = (Zombie) CriaturaFactory.createCreature(id, teamId, tipo, nome, x, y, linhaAtual);
                    zombies.add(zombie);
                    tabuleiro.adicionarZombie(x, y, zombie);
                }
            }

            boolean equipamentosPresentes = false;
            if (scanner.hasNextLine()) {
                linhaAtual++;
                String linhaEquipamentos = scanner.nextLine().trim();
                if (!linhaEquipamentos.isEmpty()) {
                    int numEquipamentos = Integer.parseInt(linhaEquipamentos);
                    equipamentosPresentes = numEquipamentos > 0;

                    for (int i = 0; i < numEquipamentos; i++) {
                        linhaAtual++;
                        String[] equipamentoInfo = scanner.nextLine().trim().split(" : ");
                        int id = Integer.parseInt(equipamentoInfo[0]);
                        int tipo = Integer.parseInt(equipamentoInfo[1]);
                        int x = Integer.parseInt(equipamentoInfo[2]);
                        int y = Integer.parseInt(equipamentoInfo[3]);

                        Equipamento equipamento = EquipamentoFactory.createEquipamento(id, tipo, x, y, linhaAtual);
                        equipamentos.add(equipamento);
                        tabuleiro.adicionarEquipamento(x, y, equipamento);
                    }
                }
            }

            if (equipamentosPresentes && scanner.hasNextLine()) {
                linhaAtual++;
                String linhaSafeHavens = scanner.nextLine().trim();
                if (!linhaSafeHavens.isEmpty()) {
                    int numSafeHavens = Integer.parseInt(linhaSafeHavens);
                    for (int i = 0; i < numSafeHavens; i++) {
                        linhaAtual++;
                        String[] safeHavenInfo = scanner.nextLine().trim().split(" : ");
                        int x = Integer.parseInt(safeHavenInfo[0]);
                        int y = Integer.parseInt(safeHavenInfo[1]);
                        SafeHaven safeHaven = new SafeHaven(x, y);
                        tabuleiro.adicionarSafeHaven(x, y, safeHaven);
                    }
                }
            }
        }
    }

    public int[] getWorldSize() {
        return new int[]{tabuleiro.getLargura(), tabuleiro.getAltura()};
    }

    public int getInitialTeamId() {
        return tabuleiro.getInitialTeamId();
    }

    public int getCurrentTeamId() {
        return tabuleiro.getCurrentTeamId();
    }

    public boolean isDay() {
        return tabuleiro.isDay();
    }

    public String getSquareInfo(int x, int y) {
        if (!tabuleiro.isPosicaoDentroDosLimites(x, y)) {
            return null;
        }
        Posicao posicao = tabuleiro.getPosicao(x, y);
        return posicao.getSquareInfo();
    }

    public String[] getCreatureInfo(int id) {
        for (Humano humano : humanos) {
            if (humano.getId() == id) {
                return humano.getCreatureInfo();
            }
        }

        for (Zombie zombie : zombies) {
            if (zombie.getId() == id) {
                return zombie.getCreatureInfo();
            }
        }

        for (Humano humano : humanosNoSafeHaven) {
            if (humano.getId() == id) {
                return humano.getCreatureInfo();
            }
        }
        return null;
    }

    public String getCreatureInfoAsString(int id) {

        for (Humano humano : humanos) {
            if (humano.getId() == id) {
                return humano.getCreatureInfoAsString();
            }
        }

        for (Zombie zombie : zombies) {
            if (zombie.getId() == id) {
                return zombie.getCreatureInfoAsString();
            }
        }

        for (Humano humano : humanosNoSafeHaven) {
            if (humano.getId() == id) {
                return humano.getCreatureInfoAsString();
            }
        }

        return null;
    }

    public String[] getEquipmentInfo(int id) {
        for (Equipamento equipamento : equipamentos) {
            if (equipamento.getId() == id) {
                return equipamento.getEquipmentInfo();
            }
        }
        return null;
    }

    public String getEquipmentInfoAsString(int id) {
        for (Equipamento equipamento : equipamentos) {
            if (equipamento.getId() == id) {
                return equipamento.getEquipmentInfoAsString();
            }
        }
        return null;
    }

    public boolean hasEquipment(int creatureId, int equipmentTypeId) {
        for (Humano humano : humanos) {
            if (humano.getId() == creatureId) {
                return humano.hasEquipment(equipmentTypeId);
            }
        }
        return false;
    }

    public boolean move(int xO, int yO, int xD, int yD) throws InvalidFileException{

        Posicao posOrigem = tabuleiro.getPosicao(xO, yO);
        Posicao posDestino = tabuleiro.getPosicao(xD, yD);
        boolean isHumanTurn = getCurrentTeamId() == 20;

        if (posOrigem == null || posDestino == null || posOrigem.isPosicaoVazia()) {
            return false;
        }

        Humano humano = posOrigem.getHumano();
        Zombie zombie = posOrigem.getZombie();

        if (isHumanTurn && humano == null || !isHumanTurn && zombie == null) {
            if(zombie == null) {
                jogadasInvalidasHumanos++;
            } else {
                jogadasInvalidasZombies++;
            }
            return false;
        }

        boolean moveResult = isHumanTurn ?
                processHumanoMove(humano, xD, yD, posOrigem, posDestino) :
                processZombieMove(zombie, xD, yD, posOrigem, posDestino);

        if (!moveResult) {
            if(zombie == null){
                jogadasInvalidasHumanos++;
            }else{
                jogadasInvalidasZombies++;
            }
        }

        if(moveResult){
            tabuleiro.incrementarJogada();
        }
        return moveResult;
    }

    private boolean processHumanoMove(Humano humano, int xD, int yD, Posicao posOrigem, Posicao posDestino) {
        // Verificar se há outro humano no destino
        if (posDestino.getHumano() != null) {
            Humano humanoDestino = posDestino.getHumano();
            if(humanoDestino.getTipoCriatura().equals("Adulto")){
               if(tentarCriarCrianca(humano, humanoDestino, humano.getX(), humano.getY())){
                   return true;
               }
            }
            return false;
        }

        // Verificar Safe Haven
        SafeHaven safeHaven = tabuleiro.getSafeHaven(xD, yD);
        if (safeHaven != null && humano.podeIrSafeHeaven()) {
            humanosNoSafeHaven.add(humano);
            humano.setInSafeHaven(true);
            posOrigem.setHumano(null);
            posDestino.setHumano(null);
            humanos.remove(humano);
            return true;
        }

        // Verificar se pode mover para o destino
        if (!humano.podeMoverPara(humano.getX(), humano.getY(), xD, yD, tabuleiro)) {
            return false;
        }

        // Processar ataque a zombie
        if (posDestino.getZombie() != null) {
            return processHumanoAttack(humano, posDestino, posOrigem, xD, yD);
        }

        // Processar equipamento e movimento
        Equipamento equipamentoDestino = posDestino.getEquipamento();
        humano.processarEquipamento(equipamentoDestino, posOrigem, posDestino, equipamentos);
        humano.executarMovimento(xD, yD, posOrigem, posDestino);
        return true;
    }

    private boolean tentarCriarCrianca(Humano humanoMove, Humano humanoDestino, int xO, int yO){
        if(humanoDestino.getX() == xO && humanoDestino.getY() == yO){
            return false;
        }

        if(humanoMove.jaProcriou()){
            return false;
        }

        int[][] posicoesAdjacentes = {
                {xO-1, yO},
                {xO, yO-1},
                {xO+1, yO},
                {xO, yO+1}
        };

        int idCrianca = Integer.parseInt(humanoMove.getId() + "" + humanoDestino.getId());
        String nomeCrianca = humanoMove.getNome() + " & " + humanoDestino.getNome();

        for (int[] pos : posicoesAdjacentes){
            int novoX = pos[0];
            int novoY = pos[1];

            if(!tabuleiro.isPosicaoDentroDosLimites(novoX, novoY)){
                continue;
            }

            Posicao posicaoAdjacente = tabuleiro.getPosicao(novoX, novoY);

            if(posicaoAdjacente.isPosicaoVazia() && posicaoAdjacente.getSafeHaven() == null){
                HumanoCrianca novaCrianca = new HumanoCrianca(
                        idCrianca,
                        20,
                        nomeCrianca,
                        novoX,
                        novoY
                );

                humanos.add(novaCrianca);
                posicaoAdjacente.setHumano(novaCrianca);
                humanoMove.setJaProcriou(true);
                return true;
            }
        }
        return false;
    }

    private boolean processHumanoAttack(Humano humano, Posicao posDestino, Posicao posOrigem, int xD, int yD) {
        Zombie zombieDestino = posDestino.getZombie();
        Equipamento equipamento = humano.getEquipamento();

        if (equipamento == null || (equipamento.getTipo() != 1 && equipamento.getTipo() != 2)) {
            return false;
        }

        if (equipamento.getTipo() == 2) {  // Pistola
            Pistola pistola = (Pistola) equipamento;
            if (pistola.getMunicao() <= 0) {
                return false;
            }
            pistola.usarPistola();
        }

        zombies.remove(zombieDestino);
        posDestino.setZombie(null);
        humano.executarMovimento(xD, yD, posOrigem, posDestino);
        tabuleiro.resetTurnosSemTransformacao();
        return true;
    }

    private boolean processZombieMove(Zombie zombie, int xD, int yD, Posicao posOrigem, Posicao posDestino) throws InvalidFileException {
        // Verificar Safe Haven
        SafeHaven safeHaven = tabuleiro.getSafeHaven(xD, yD);
        if (safeHaven != null) {
            return false;
        }

        // Verificar se há outro zombie no destino
        if (posDestino.getZombie() != null) {
            return false;
        }

        // Verificar se pode mover para o destino
        if (!zombie.podeMoverPara(zombie.getX(), zombie.getY(), xD, yD, tabuleiro)) {
            return false;
        }

        Humano humanoDestino = posDestino.getHumano();

        // Se não há humano no destino, move normalmente
        if (humanoDestino == null) {
            zombie.executarMovimento(xD, yD, posOrigem, posDestino);
            Equipamento equipamentoDestino = posDestino.getEquipamento();
            if (equipamentoDestino != null) {
                equipamentos.remove(equipamentoDestino);
                posDestino.setEquipamento(null);
            }
            return true;
        }

        // Processar interação com humano
        return processZombieHumanoInteraction(zombie, humanoDestino, posDestino);
    }

    private boolean processZombieHumanoInteraction(Zombie zombie, Humano humano, Posicao posDestino) throws InvalidFileException {
        if (!humano.podeSerTransformado()) {
            return false;
        }

        Equipamento equipHumano = humano.getEquipamento();

        // Caso 1: Humano sem equipamento
        if (equipHumano == null) {
            transformarHumanoEmZombie(humano, posDestino);
            return true;
        }

        // Caso 2: Humano com equipamento defensivo
        if (equipHumano.getTipo() == 0 || equipHumano.getTipo() == 3) {
            if (equipHumano.getTipo() == 3) {
                Lixivia lixivia = (Lixivia) equipHumano;
                if (!lixivia.usarLixivia()) {
                    humano.setEquipamento(null);
                    if (humano.podeSerTransformado()) {
                        transformarHumanoEmZombie(humano, posDestino);
                    }
                }
            }
            return true;
        }

        // Caso 3: Humano com equipamento ofensivo
        if (equipHumano.getTipo() == 1 || equipHumano.getTipo() == 2) {
            if (equipHumano.getTipo() == 2) {  // Se for pistola
                Pistola pistola = (Pistola) equipHumano;
                if (pistola.getMunicao() == 0) {
                    humano.setEquipamento(null);
                    if (humano.podeSerTransformado()) {
                        transformarHumanoEmZombie(humano, posDestino);
                    }
                }
                pistola.usarPistola();
            }
            return true;
        }

        return false; //retentar
    }

    public boolean gameIsOver() {
        // Condição 1: Só há humanos no tabuleiro
        if (zombies.isEmpty() && !humanos.isEmpty()) {
            return true;
        }

        // Condição 2: Só há zombies no tabuleiro
        if (humanos.isEmpty() && !zombies.isEmpty()) {
            return true;
        }

        // Condição 3: 8 turnos sem transformação ou morte
        if (tabuleiro.getTurnosSemTransformacao() >= 8 && !humanos.isEmpty() && !zombies.isEmpty()) {
            return true;
        }

        // Condição 4: Verifica se algum dos lados atingiu 6 jogadas inválidas
        if (jogadasInvalidasHumanos >= 6 || jogadasInvalidasZombies >= 6) {
            return true;
        }
        return false;
    }


    public ArrayList<String> getSurvivors() {
        ArrayList<String> survivors = new ArrayList<>();

        survivors.add("Nr. de turnos terminados:");
        survivors.add(String.valueOf(tabuleiro.getNumJogadas()));

        survivors.add("Nr. de jogadas invalidas:");
        survivors.add("humanos:" + jogadasInvalidasHumanos + " " + "zombies:" + jogadasInvalidasZombies);
        survivors.add("");

        ArrayList<Humano> vivos = new ArrayList<>(humanos);
        vivos.addAll(humanosNoSafeHaven);
        ArrayList<Zombie> outros = new ArrayList<>(zombies);

        // Ordena os zombies pelo id e humanos tmb
        vivos.sort(Comparator.comparingInt(Entidade::getId));
        outros.sort(Comparator.comparingInt(Entidade::getId));

        survivors.add("OS VIVOS");
        for (Humano humano : vivos) {
            survivors.add(humano.getId() + " " + humano.getNome());
        }

        survivors.add("");

        survivors.add("OS OUTROS");
        for (Zombie zombie : outros) {
            survivors.add(zombie.getId() + " (antigamente conhecido como " + zombie.getNome() + ")");
        }
        survivors.add("-----");
        return survivors;
    }

    private void transformarHumanoEmZombie(Humano humano, Posicao posicao) throws InvalidFileException{

        try {
            int equipamentosAcumulados = humano.getEquipamentosAcumulados();
            // Cria um novo zombie com os dados do humano
            Zombie novoZombie = (Zombie) CriaturaFactory.createCreature(
                    humano.getId(),
                    10, // teamId dos zombies
                    humano.getTipoZombie(),
                    humano.getNome(),
                    humano.getX(),
                    humano.getY(),
                    -1
            );

            novoZombie.setFoiTransformado(true);

            for (int i = 0; i < equipamentosAcumulados; i++) {
                novoZombie.incrementarEquipamentosDestruidos();
            }
            // Remove o humano
            humanos.remove(humano);
            posicao.setHumano(null);

            // Adiciona o novo zombie
            zombies.add(novoZombie);
            posicao.setZombie(novoZombie);
            tabuleiro.resetTurnosSemTransformacao();
        } catch (InvalidFileException e) {
            throw new InvalidFileException("erro ao transformar humano em zombie", 0);
        }
    }

    public List<Integer> getIdsInSafeHaven() {
        List<Integer> ids = new ArrayList<>();
        for (Humano humano : humanosNoSafeHaven) {
            ids.add(humano.getId());
        }
        return ids;
    }

    public void saveGame(File file) throws IOException {
        if (file == null || tabuleiro == null) {
            throw new IllegalArgumentException("Arquivo ou tabuleiro inválido.");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Dimensões do tabuleiro
            writer.write(tabuleiro.getLargura() + " " + tabuleiro.getAltura());
            writer.newLine();

            // Team inicial
            writer.write(String.valueOf(tabuleiro.getInitialTeamId()));
            writer.newLine();

            // Número de criaturas (humanos + zombies)
            int totalCriaturas = humanos.size() + zombies.size();
            writer.write(String.valueOf(totalCriaturas));
            writer.newLine();

            // Escreve humanos
            for (Humano humano : humanos) {
                writer.write(humano.getId() + " : " +
                        "20" + " : " +  // teamId dos humanos
                        humano.getTipoZombie() + " : " +
                        humano.getNome() + " : " +
                        humano.getX() + " : " +
                        humano.getY());
                writer.newLine();
            }

            // Escreve zombies
            for (Zombie zombie : zombies) {
                writer.write(zombie.getId() + " : " +
                        "10" + " : " +  // teamId dos zombies
                        zombie.getTipoZombie() + " : " +  // agora usa o tipo correto do zombie
                        zombie.getNome() + " : " +
                        zombie.getX() + " : " +
                        zombie.getY());
                writer.newLine();
            }

            // Número de equipamentos
            writer.write(String.valueOf(equipamentos.size()));
            writer.newLine();

            // Escreve equipamentos
            for (Equipamento equipamento : equipamentos) {
                writer.write(equipamento.getId() + " : " +
                        equipamento.getTipo() + " : " +
                        equipamento.getX() + " : " +
                        equipamento.getY());
                writer.newLine();
            }

            // Contagem de SafeHavens e suas posições
            ArrayList<SafeHaven> safeHavens = tabuleiro.getSafeHavens();
            writer.write(String.valueOf(safeHavens.size()));
            writer.newLine();

            for (SafeHaven safeHaven : safeHavens) {
                writer.write(safeHaven.getX() + " : " + safeHaven.getY());
                writer.newLine();
            }
        }
    }

    public JPanel getCreditsPanel() {
        return new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("resources/images/capacetes.png");
                Image image = icon.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
    }

    public HashMap<String, String> customizeBoard() {
        HashMap<String, String> customizations = new HashMap<>();

        customizations.put("title", "Informatica MasterClass");

        customizations.put("imageBackgroundDay", "informaticadia.jpg");
        customizations.put("imageBackgroundNight", "fimnanoite.jpg");

        return customizations;

    }
}
