package pt.ulusofona.lp2.thenightofthelivingdeisi;

public class Main {

}
