package pt.ulusofona.lp2.thenightofthelivingdeisi.factories;

import pt.ulusofona.lp2.thenightofthelivingdeisi.InvalidFileException;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.EscudoMadeira;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.EspadaSamurai;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Lixivia;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Pistola;

public class EquipamentoFactory {
    public static Equipamento createEquipamento(int id, int tipo, int x, int y, int linha) throws InvalidFileException {
        return switch (tipo) {
            case 0 -> new EscudoMadeira(id, x, y);
            case 1 -> new EspadaSamurai(id, x, y);
            case 2 -> new Pistola(id, x, y);
            case 3 -> new Lixivia(id, x, y);
            default -> throw new InvalidFileException("Tipo de equipamento invalido", linha);
        };
    }
}
