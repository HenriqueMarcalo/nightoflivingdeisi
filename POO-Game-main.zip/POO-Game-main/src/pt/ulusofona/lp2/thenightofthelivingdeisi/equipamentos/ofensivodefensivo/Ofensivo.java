package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo;

import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;

public abstract class Ofensivo extends Equipamento {
    public Ofensivo(int id, int tipo, int x, int y) {
        super(id, tipo, x, y);
    }

    public boolean getOfensivo(){
        return true;
    }
}