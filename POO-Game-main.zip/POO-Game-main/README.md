![](diagrama.png?raw=true "Diagrama UML")

MODULAÇÃO:

Para este projeto seguir todas as regras de programação OO, e as suas boas práticas, decidimos criar a classe
Entidade que vai ser herdada pelas classes Equipamento, Humano e Zombie porque todos estes têm em comum os atributos
ID, X e Y.

De seguida, fez-nos sentido criar para a classe Humano, 5 subclasses (Cão, Adulto, Criança, Idoso, Rambo)
porque são todos humanos, criámos também 4 subclasses para os Zombies (Vampiro, Adulto, Criança, Idoso).
Para os Equipamentos decidimos dividir entre Ofensivos (Espada e Pistola) e Defensivos (Escudo e Lixívia).

Decidimos também criar as factories para instanciarmos os objetos para evitar as más práticas e porque 
é e foi bastante útil.

CREATIVIDADE:

Criámos o Rambo, o Rambo é um humano que se pode mover 3 posiçoes na horizontal e na vertical.
Não pode ser transformado pelos Zombies, porque é o Rambo e pode apanhar todo o tipo de equipamentos.
Pode matar os Zombies. 

URL VIDEO:

https://youtu.be/i50_hTJHvdI
