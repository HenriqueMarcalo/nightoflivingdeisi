package pt.ulusofona.lp2.thenightofthelivingdeisi.zombies;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

public class Vampiro extends Zombie {
    public Vampiro(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 4, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Vampiro";
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        if (tabuleiro.isDay()) {
            return false;
        }
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);
        return deltaX <= 1 && deltaY <= 1;
    }

    @Override
    public String getCreatureInfoAsString() {
        return getId() + " | Vampiro | " + getNome() + " | -" +getEquipamentosDestruidos() + " @ (" + getX() + ", " + getY() + ")";
    }
}