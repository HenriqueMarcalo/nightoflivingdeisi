package pt.ulusofona.lp2.thenightofthelivingdeisi.humanos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;

import java.util.ArrayList;

public class Rambo extends Humano {
    public Rambo(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 5, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Rambo";
    }

    @Override
    public boolean podeUsar(Equipamento equipamento) {
        return true;
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);

        // permitir movimento de até 3 posicoes apenas na vertical ou horizontal
        if ((deltaX == 0 && deltaY <= 3) || (deltaY == 0 && deltaX <= 3)) {
            return true;
        }

        // nao permitir movimento na diagonal
        return false;
    }

    @Override
    public int getTipoZombie() {
        return -1; // Este valor nunca será usado
    }

    @Override
    public boolean podeSerTransformado() {
        return false;
    }

    @Override
    public boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos) {
        if (equipamento != null && podeUsar(equipamento)) {
            // Se já tem um equipamento, deixa na posição original antes de pegar o novo
            if (getEquipamento() != null) {
                Equipamento equipamentoAtual = getEquipamento();
                equipamentos.add(equipamentoAtual); // este é oq dropa
                equipamentoAtual.setCapturado(false);
                setEquipamento(null);
                posOrigem.setEquipamento(equipamentoAtual);
            }
            // Pega o novo equipamento se for defensivo
            equipamento.setCapturado(true);
            setEquipamento(equipamento);
            posDestino.setEquipamento(null);
            equipamentos.remove(equipamento);
            return true;
        }
        return false;
    }

    @Override
    public String getCreatureInfoAsString() {
        String info;
        if (isInSafeHaven()) {
            info = getId() + " | Rambo | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ Safe Haven";
        } else {
            info = getId() + " | Rambo | Humano | " + getNome() + " | +" + getEquipamentosAcumulados() + " @ (" + getX() + ", " + getY() + ")";
        }
        if (getEquipamento() != null) {
            info += " | " + getEquipamento().getEquipmentInfoAsString();
        }
        return info;
    }
}