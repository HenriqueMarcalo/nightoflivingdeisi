package pt.ulusofona.lp2.thenightofthelivingdeisi.humanos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;

import java.util.ArrayList;

public class Cao extends Humano {
    public Cao(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 3, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Cão";
    }

    @Override
    public boolean podeUsar(Equipamento equipamento) {
        return false; // Não pode usar nenhum equipamento
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        if (tabuleiro.getPosicao(xDestino, yDestino).getEquipamento() != null) {
            return false; // Cão não pode mover para posições com equipamento
        }

        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);
        return (deltaX > 0 && deltaX <= 2 && deltaY == 0) || (deltaY > 0 && deltaY <= 2 && deltaX == 0);
    }

    @Override
    public int getTipoZombie() {
        return 3; // Este valor nunca será usado
    }

    @Override
    public boolean podeSerTransformado() {
        return false; // Cão não pode ser transformado
    }

    @Override
    public boolean processarEquipamento(Equipamento equipamento, Posicao posOrigem, Posicao posDestino, ArrayList<Equipamento> equipamentos) {
        return false; // Cão nunca processa equipamentos
    }

    @Override
    public String getCreatureInfoAsString() {
        if (isInSafeHaven()) {
            return getId() + " | Cão | " + getNome() + " @ Safe Haven";
        }
        return getId() + " | Cão | " + getNome() + " @ (" + getX() + ", " + getY() + ")";
    }

}