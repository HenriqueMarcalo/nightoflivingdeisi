package pt.ulusofona.lp2.thenightofthelivingdeisi.zombies;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

public class ZombieCrianca extends Zombie {
    public ZombieCrianca(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 0, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Criança";
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);
        return (deltaX == 1 && deltaY == 0) || (deltaY == 1 && deltaX == 0);
    }

    @Override
    public String getCreatureInfoAsString() {
        String txt = foiTransformado ? " (Transformado)" : "";
        return getId() + " | Criança | Zombie" + txt + " | " + getNome() + " | -" + getEquipamentosDestruidos() + " @ (" + getX() + ", " + getY() + ")";
    }
}