package pt.ulusofona.lp2.thenightofthelivingdeisi;

import org.junit.jupiter.api.Test;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.EscudoMadeira;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.EspadaSamurai;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Lixivia;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.Pistola;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Defensivo;
import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Ofensivo;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.Cao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.HumanoAdulto;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.HumanoCrianca;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.HumanoIdoso;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.Vampiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieAdulto;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieCrianca;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieIdoso;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class Teste {

    @Test
    public void testLoadGame() throws IOException, InvalidFileException {
        GameManager manager = new GameManager();
        File file = new File("test-files/test1.txt");
        manager.loadGame(file);

        int[] size = manager.getWorldSize();
        assertEquals(7, size[0]);
        assertEquals(7, size[1]);

        assertEquals(10, manager.getInitialTeamId());

        assertNotNull(manager.getCreatureInfo(1));
        assertNotNull(manager.getCreatureInfo(10));

        assertNotNull(manager.getEquipmentInfo(-1));
        assertNotNull(manager.getEquipmentInfo(-4));
    }

    @Test
    public void testInvalidHumanMove() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertFalse(manager.move(3, 4, -1, -1));
    }

    @Test
    public void testZombieTransformHuman() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertTrue(manager.move(3, 3, 3, 4));
        assertNull(manager.getCreatureInfo(20)); // Verifica se humano foi transformado
    }

    @Test
    public void testGetSquareInfo() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertEquals("H:6", manager.getSquareInfo(3, 4));
        assertEquals("Z:1", manager.getSquareInfo(3, 3));
        assertEquals("E:-1", manager.getSquareInfo(6, 3));
    }

    @Test
    public void testGetCreatureInfo() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        String[] info = manager.getCreatureInfo(6);
        assertEquals("Karate Kid", info[3]);
    }

    @Test
    public void testGetSurvivors() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        ArrayList<String> survivors = manager.getSurvivors();
        assertTrue(survivors.contains("OS VIVOS"));
        assertTrue(survivors.contains("OS OUTROS"));
    }

    @Test
    public void testLixivia() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test3.txt"));

        manager.move(3, 3, 2, 3);
        assertTrue(manager.hasEquipment(2, 3));

        assertTrue(manager.move(1, 3, 2, 3));
        assertTrue(manager.move(2,3, 0, 3));
        assertTrue(manager.hasEquipment(2, 1));
    }

    @Test
    public void testLoadGame2() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        int[] size = manager.getWorldSize();
        assertEquals(7, size[0]);
        assertEquals(7, size[1]);
        assertEquals(10, manager.getInitialTeamId());
    }

    @Test
    public void testZombieMovement() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertTrue(manager.move(3, 3, 3, 4));
        assertFalse(manager.move(3, 4, 6, 6));
    }

    @Test
    public void testSaveGame() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        File saveFile = new File("test-files/save_test.txt");
        manager.saveGame(saveFile);
        assertTrue(saveFile.exists());
    }

    @Test
    public void testInvalidMoves() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertFalse(manager.move(-1, -1, 0, 0));
        assertFalse(manager.move(7, 7, 8, 8));
        assertFalse(manager.move(3, 4, 3, 4));
    }

    @Test
    public void testCreatureInfo() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        String[] info = manager.getCreatureInfo(6);
        assertEquals("Karate Kid", info[3]);

        String infoString = manager.getCreatureInfoAsString(6);
        assertTrue(infoString.contains("Karate Kid"));
    }

    @Test
    public void testGameStateSurvivors() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        List<String> survivors = manager.getSurvivors();
        assertFalse(survivors.isEmpty());
        assertTrue(survivors.contains("OS VIVOS"));
    }

    @Test
    public void testSquareInfo() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        String info = manager.getSquareInfo(3, 4);
        assertNotNull(info);
        assertTrue(info.startsWith("H:") || info.startsWith("Z:") || info.startsWith("E:") || info.equals("SH"));
    }

    @Test
    public void testHumanoAdulto() throws InvalidFileException {
        HumanoAdulto adulto = new HumanoAdulto(1, 20, "Test", 0, 0);
        assertTrue(adulto.podeSerTransformado());
        assertEquals(1, adulto.getTipoZombie());
        assertTrue(adulto.podeUsar(new EspadaSamurai(1, 0, 0)));
    }

    @Test
    public void testHumanoCrianca() throws InvalidFileException {
        HumanoCrianca crianca = new HumanoCrianca(1, 20, "Test", 0, 0);
        assertTrue(crianca.podeSerTransformado());
        assertTrue(crianca.podeUsar(new EscudoMadeira(1, 0, 0)));
        assertFalse(crianca.podeUsar(new EspadaSamurai(1, 0, 0)));
    }

    @Test
    public void testHumanoIdoso() throws InvalidFileException {
        HumanoIdoso idoso = new HumanoIdoso(1, 20, "Test", 0, 0);
        assertTrue(idoso.podeSerTransformado());
        assertTrue(idoso.podeUsar(new EspadaSamurai(1, 0, 0)));
        assertEquals(2, idoso.getTipoZombie());
    }

    @Test
    public void testCao() throws InvalidFileException {
        Cao cao = new Cao(1, 20, "Test", 0, 0);
        assertFalse(cao.podeSerTransformado());
        assertFalse(cao.podeUsar(new EscudoMadeira(1, 0, 0)));
    }

    @Test
    public void testZombieAdulto() {
        ZombieAdulto zombie = new ZombieAdulto(1, 10, "Test", 0, 0);
        assertTrue(zombie.podeMoverPara(0, 0, 2, 0, new Tabuleiro(5, 5)));
        assertFalse(zombie.podeMoverPara(0, 0, 3, 0, new Tabuleiro(5, 5)));
    }

    @Test
    public void testZombieCrianca() {
        ZombieCrianca zombie = new ZombieCrianca(1, 10, "Test", 0, 0);
        assertTrue(zombie.podeMoverPara(0, 0, 1, 0, new Tabuleiro(5, 5)));
        assertFalse(zombie.podeMoverPara(0, 0, 1, 1, new Tabuleiro(5, 5)));
    }

    @Test
    public void testZombieIdoso() {
        ZombieIdoso zombie = new ZombieIdoso(1, 10, "Test", 0, 0);
        assertTrue(zombie.podeMoverPara(0, 0, 1, 1, new Tabuleiro(5, 5)));
        assertFalse(zombie.podeMoverPara(0, 0, 2, 2, new Tabuleiro(5, 5)));
    }

    @Test
    public void testVampiro() {
        Vampiro vampiro = new Vampiro(1, 10, "Test", 0, 0);
        Tabuleiro tab = new Tabuleiro(5, 5);
        tab.incrementarJogada();// Make it night
        tab.incrementarJogada();
        assertTrue(vampiro.podeMoverPara(0, 0, 1, 1, tab));
        assertFalse(vampiro.podeMoverPara(0, 0, 2, 2, tab));
    }

    @Test
    public void testEquipamentos() {
        Pistola pistola = new Pistola(1, 0, 0);
        assertEquals(3, pistola.getMunicao());
        assertTrue(pistola.usarPistola());
        assertEquals(2, pistola.getMunicao());

        Lixivia lixivia = new Lixivia(1, 0, 0);
        assertEquals(1.0, lixivia.getCapacidade());
        assertTrue(lixivia.usarLixivia());
        assertEquals(0.7, lixivia.getCapacidade(), 0.01);
    }

    @Test
    public void testPosicao() {
        Posicao pos = new Posicao(1, 1);

        assertTrue(pos.isPosicaoVazia());
        assertNull(pos.getHumano());
        assertNull(pos.getZombie());
        assertNull(pos.getEquipamento());
        assertEquals("", pos.getSquareInfo());

        HumanoAdulto humano = new HumanoAdulto(1, 20, "Test", 1, 1);
        pos.setHumano(humano);
        assertEquals("H:1", pos.getSquareInfo());
        assertFalse(pos.isPosicaoVazia());

        pos.setHumano(null);
        ZombieAdulto zombie = new ZombieAdulto(2, 10, "TestZ", 1, 1);
        pos.setZombie(zombie);
        assertEquals("Z:2", pos.getSquareInfo());

        pos.setZombie(null);
        Pistola pistola = new Pistola(3, 1, 1);
        pos.setEquipamento(pistola);
        assertEquals("E:3", pos.getSquareInfo());


        assertEquals(1, pos.getX());
        assertEquals(1, pos.getY());
    }

    @Test
    public void testTabuleiro() {
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertEquals(5, tab.getLargura());
        assertEquals(5, tab.getAltura());
        assertTrue(tab.isPosicaoDentroDosLimites(2, 2));
        assertFalse(tab.isPosicaoDentroDosLimites(5, 5));

        tab.setInitialTeamId(20);
        assertEquals(20, tab.getInitialTeamId());
        assertEquals(20, tab.getCurrentTeamId());

        assertTrue(tab.isDay());
        tab.incrementarJogada();
        tab.incrementarJogada();
        assertFalse(tab.isDay());

        assertEquals(2, tab.getTurnosSemTransformacao());
        tab.resetTurnosSemTransformacao();
        assertEquals(-1, tab.getTurnosSemTransformacao());

        HumanoAdulto humano = new HumanoAdulto(1, 20, "Test", 2, 2);
        tab.adicionarHumano(2, 2, humano);
        assertNotNull(tab.getPosicao(2, 2).getHumano());

        SafeHaven sh = new SafeHaven(3, 3);
        tab.adicionarSafeHaven(3, 3, sh);
        assertEquals(sh, tab.getSafeHaven(3, 3));
        assertNotNull(tab.getSafeHavens());
    }

    @Test
    public void testHumanoAdulto2() {
        HumanoAdulto adulto = new HumanoAdulto(1, 20, "Test", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(adulto.podeMoverPara(2, 2, 3, 3, tab));

        assertEquals("Adulto", adulto.getTipoCriatura());
        assertFalse(adulto.isInSafeHaven());
        adulto.setInSafeHaven(true);
        assertTrue(adulto.isInSafeHaven());

        Pistola pistola = new Pistola(2, 2, 2);
        assertTrue(adulto.podeUsar(pistola));
        adulto.setEquipamento(pistola);
        assertTrue(adulto.hasEquipment(2));

        String info = adulto.getCreatureInfoAsString();
        assertTrue(info.contains("Adulto"));
        assertTrue(info.contains("Test"));
    }

    @Test
    public void testHumanoCrianca2() {
        HumanoCrianca crianca = new HumanoCrianca(1, 20, "Test", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(crianca.podeMoverPara(2, 2, 2, 3, tab));
        assertFalse(crianca.podeMoverPara(2, 2, 2, 4, tab));

        EscudoMadeira escudo = new EscudoMadeira(2, 2, 2);
        assertTrue(crianca.podeUsar(escudo));
        crianca.setEquipamento(escudo);

        EspadaSamurai espada = new EspadaSamurai(3, 2, 2);
        assertFalse(crianca.podeUsar(espada));

        assertEquals(0, crianca.getTipoZombie());
        assertTrue(crianca.podeIrSafeHeaven());
    }

    @Test
    public void testHumanoIdoso2() {
        HumanoIdoso idoso = new HumanoIdoso(1, 20, "Test", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(idoso.podeMoverPara(2, 2, 3, 3, tab));
        assertFalse(idoso.podeMoverPara(2, 2, 4, 4, tab));

        tab.incrementarJogada();  // Make it night

        Lixivia lixivia = new Lixivia(2, 2, 2);
        assertTrue(idoso.podeUsar(lixivia));
        idoso.setEquipamento(lixivia);

        assertEquals(2, idoso.getTipoZombie());
    }

    @Test
    public void testEquipamentos2() {
        Pistola pistola = new Pistola(1, 1, 1);
        for (int i = 0; i < 3; i++) {
            assertTrue(pistola.usarPistola());
        }
        assertFalse(pistola.usarPistola());
        assertEquals(0, pistola.getMunicao());

        Lixivia lixivia = new Lixivia(2, 1, 1);
        assertEquals(1.0, lixivia.getCapacidade());

        for (int i = 0; i < 3; i++) {
            assertTrue(lixivia.usarLixivia());
            assertTrue(lixivia.getCapacidade() > 0);
        }

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.0, lixivia.getCapacidade(), 0.01);

        assertFalse(lixivia.usarLixivia());
    }

    @Test
    public void testZombieTypes() {
        Tabuleiro tab = new Tabuleiro(5, 5);

        ZombieCrianca zCrianca = new ZombieCrianca(1, 10, "TestC", 2, 2);
        assertTrue(zCrianca.podeMoverPara(2, 2, 2, 3, tab));
        assertFalse(zCrianca.podeMoverPara(2, 2, 3, 3, tab));

        ZombieAdulto zAdulto = new ZombieAdulto(2, 10, "TestA", 2, 2);
        assertTrue(zAdulto.podeMoverPara(2, 2, 3, 3, tab));

        ZombieIdoso zIdoso = new ZombieIdoso(3, 10, "TestI", 2, 2);
        assertTrue(zIdoso.podeMoverPara(2, 2, 3, 3, tab));
        assertFalse(zIdoso.podeMoverPara(2, 2, 4, 4, tab));

        Vampiro vampiro = new Vampiro(4, 10, "TestV", 2, 2);
        assertFalse(vampiro.podeMoverPara(2, 2, 3, 3, tab));
        tab.incrementarJogada(); // Make it night
        tab.incrementarJogada();
        assertTrue(vampiro.podeMoverPara(2, 2, 3, 3, tab));
    }

    @Test
    public void testHumanoCriancaMetodos() {
        HumanoCrianca crianca = new HumanoCrianca(1, 20, "TestCrianca", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertEquals("Criança", crianca.getTipoCriatura());

        assertTrue(crianca.podeMoverPara(2, 2, 2, 3, tab));
        assertTrue(crianca.podeMoverPara(2, 2, 3, 2, tab));

        assertFalse(crianca.podeMoverPara(2, 2, 4, 2, tab));
        assertFalse(crianca.podeMoverPara(2, 2, 2, 4, tab));
        assertFalse(crianca.podeMoverPara(2, 2, 3, 3, tab));

        EscudoMadeira escudo = new EscudoMadeira(2, 2, 2);
        assertTrue(crianca.podeUsar(escudo));
        EspadaSamurai espada = new EspadaSamurai(3, 2, 2);
        assertFalse(crianca.podeUsar(espada));
        Pistola pistola = new Pistola(4, 2, 2);
        assertFalse(crianca.podeUsar(pistola));

        Posicao posOrigem = new Posicao(2, 2);
        Posicao posDestino = new Posicao(2, 3);
        ArrayList<Equipamento> equipamentos = new ArrayList<>();

        posDestino.setEquipamento(escudo);
        equipamentos.add(escudo);
        assertTrue(crianca.processarEquipamento(escudo, posOrigem, posDestino, equipamentos));

        String info = crianca.getCreatureInfoAsString();
        assertTrue(info.contains("Criança"));
        assertTrue(info.contains("TestCrianca"));

        assertEquals(0, crianca.getTipoZombie());
        assertTrue(crianca.podeSerTransformado());
    }

    @Test
    public void testHumanoAdultoMetodos() {
        HumanoAdulto adulto = new HumanoAdulto(1, 20, "TestAdulto", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(adulto.podeMoverPara(2, 2, 4, 2, tab));
        assertTrue(adulto.podeMoverPara(2, 2, 2, 4, tab));
        assertTrue(adulto.podeMoverPara(2, 2, 4, 4, tab));

        assertFalse(adulto.podeMoverPara(2, 2, 5, 2, tab));
        assertFalse(adulto.podeMoverPara(2, 2, 2, 5, tab));

        EspadaSamurai espada = new EspadaSamurai(2, 2, 2);
        assertTrue(adulto.podeUsar(espada));
        Pistola pistola = new Pistola(3, 2, 2);
        assertTrue(adulto.podeUsar(pistola));

        Posicao posOrigem = new Posicao(2, 2);
        Posicao posDestino = new Posicao(2, 3);
        ArrayList<Equipamento> equipamentos = new ArrayList<>();

        posDestino.setEquipamento(espada);
        equipamentos.add(espada);
        assertTrue(adulto.processarEquipamento(espada, posOrigem, posDestino, equipamentos));

        Pistola novaPistola = new Pistola(4, 2, 3);
        posDestino.setEquipamento(novaPistola);
        equipamentos.add(novaPistola);
        assertTrue(adulto.processarEquipamento(novaPistola, posOrigem, posDestino, equipamentos));

        assertEquals(2, adulto.getEquipamentosAcumulados());
    }

    @Test
    public void testHumanoIdosoMetodos() {
        HumanoIdoso idoso = new HumanoIdoso(1, 20, "TestIdoso", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(idoso.podeMoverPara(2, 2, 3, 3, tab));
        tab.incrementarJogada();// noite
        tab.incrementarJogada();
        assertFalse(idoso.podeMoverPara(2, 2, 3, 3, tab));

        assertFalse(idoso.podeMoverPara(2, 2, 4, 4, tab));
        assertFalse(idoso.podeMoverPara(2, 2, 2, 3, tab));

        Posicao posOrigem = new Posicao(2, 2);
        Posicao posDestino = new Posicao(3, 3);
        ArrayList<Equipamento> equipamentos = new ArrayList<>();

        Lixivia lixivia = new Lixivia(2, 3, 3);
        posDestino.setEquipamento(lixivia);
        equipamentos.add(lixivia);
        assertFalse(idoso.processarEquipamento(lixivia, posOrigem, posDestino, equipamentos));

        idoso.executarMovimento(3, 3, posOrigem, posDestino);
        assertEquals(3, idoso.getX());
        assertEquals(3, idoso.getY());
    }

    @Test
    public void testCaoMetodos() {
        Cao cao = new Cao(1, 20, "TestCao", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(cao.podeMoverPara(2, 2, 4, 2, tab));
        assertTrue(cao.podeMoverPara(2, 2, 2, 4, tab));
        assertFalse(cao.podeMoverPara(2, 2, 3, 3, tab));

        Posicao posOrigem = new Posicao(2, 2);
        Posicao posDestino = new Posicao(2, 3);
        ArrayList<Equipamento> equipamentos = new ArrayList<>();
        EscudoMadeira escudo = new EscudoMadeira(2, 2, 3);

        assertFalse(cao.podeUsar(escudo));
        assertFalse(cao.processarEquipamento(escudo, posOrigem, posDestino, equipamentos));
        assertFalse(cao.podeSerTransformado());
    }

    @Test
    public void testZombieCriancaMetodos() {
        ZombieCrianca zCrianca = new ZombieCrianca(1, 10, "TestZCrianca", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(zCrianca.podeMoverPara(2, 2, 2, 3, tab));
        assertTrue(zCrianca.podeMoverPara(2, 2, 3, 2, tab));
        assertFalse(zCrianca.podeMoverPara(2, 2, 3, 3, tab));

        Posicao posOrigem = new Posicao(2, 2);
        Posicao posDestino = new Posicao(2, 3);
        EscudoMadeira escudo = new EscudoMadeira(2, 2, 3);
        posDestino.setEquipamento(escudo);

        zCrianca.executarMovimento(2, 3, posOrigem, posDestino);
        assertEquals(1, zCrianca.getEquipamentosDestruidos());
    }

    @Test
    public void testZombieAdultoMetodos() {
        ZombieAdulto zAdulto = new ZombieAdulto(1, 10, "TestZAdulto", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(zAdulto.podeMoverPara(2, 2, 4, 2, tab));
        assertTrue(zAdulto.podeMoverPara(2, 2, 2, 4, tab));
        assertTrue(zAdulto.podeMoverPara(2, 2, 4, 4, tab));
        assertFalse(zAdulto.podeMoverPara(2, 2, 5, 5, tab));

        zAdulto.setFoiTransformado(true);
        String info = zAdulto.getCreatureInfoAsString();
        assertTrue(info.contains("Transformado"));
    }

    @Test
    public void testZombieIdosoMetodos() {
        ZombieIdoso zIdoso = new ZombieIdoso(1, 10, "TestZIdoso", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertTrue(zIdoso.podeMoverPara(2, 2, 3, 3, tab));
        assertTrue(zIdoso.podeMoverPara(2, 2, 1, 1, tab));
        assertFalse(zIdoso.podeMoverPara(2, 2, 4, 4, tab));

        String[] info = zIdoso.getCreatureInfo();
        assertEquals("Idoso", info[1]);
        assertEquals("Zombie", info[2]);
    }

    @Test
    public void testVampiroMetodos() {
        Vampiro vampiro = new Vampiro(1, 10, "TestVampiro", 2, 2);
        Tabuleiro tab = new Tabuleiro(5, 5);

        assertFalse(vampiro.podeMoverPara(2, 2, 3, 3, tab)); // dia
        tab.incrementarJogada(); // noite
        tab.incrementarJogada();
        assertTrue(vampiro.podeMoverPara(2, 2, 3, 3, tab));

        assertFalse(vampiro.podeMoverPara(2, 2, 4, 4, tab));
        assertTrue(vampiro.podeMoverPara(2, 2, 3, 2, tab));

        String info = vampiro.getCreatureInfoAsString();
        assertTrue(info.contains("Vampiro"));
        assertTrue(info.contains("TestVampiro"));
    }

    @Test
    public void testDefensivo() {
        EscudoMadeira escudo = new EscudoMadeira(1, 2, 3);

        assertEquals(1, escudo.getId());
        assertEquals(0, escudo.getTipo());
        assertEquals(2, escudo.getX());
        assertEquals(3, escudo.getY());

        escudo.atualizarCoordenadas(4, 5);
        assertEquals(4, escudo.getX());
        assertEquals(5, escudo.getY());

        String[] info = escudo.getEquipmentInfo();
        assertEquals("1", info[0]);
        assertEquals("0", info[1]);
        assertEquals("4", info[2]);
        assertEquals("5", info[3]);

        String infoString = escudo.getEquipmentInfoAsString();
        assertTrue(infoString.contains("Escudo de madeira"));
        assertTrue(infoString.contains("(4, 5)"));
    }

    @Test
    public void testOfensivo() {
        EspadaSamurai espada = new EspadaSamurai(1, 2, 3);

        assertEquals(1, espada.getId());
        assertEquals(1, espada.getTipo());
        assertEquals(2, espada.getX());
        assertEquals(3, espada.getY());

        espada.atualizarCoordenadas(4, 5);
        assertEquals(4, espada.getX());
        assertEquals(5, espada.getY());
        espada.atualizarCoordenadas(6, 7);
        assertEquals(6, espada.getX());
        assertEquals(7, espada.getY());

        String[] info = espada.getEquipmentInfo();
        assertEquals("1", info[0]);
        assertEquals("1", info[1]);
        assertEquals("6", info[2]);
        assertEquals("7", info[3]);
    }

    @Test
    public void testEspadaSamurai() {
        EspadaSamurai espada = new EspadaSamurai(1, 2, 3);

        espada.atualizarCoordenadas(4, 5);
        assertEquals(4, espada.getX());
        assertEquals(5, espada.getY());

        String infoString = espada.getEquipmentInfoAsString();
        assertTrue(infoString.contains("Espada samurai"));
        assertTrue(infoString.contains("(4, 5)"));

        espada.atualizarCoordenadas(6, 7);
        infoString = espada.getEquipmentInfoAsString();
        assertTrue(infoString.contains("(6, 7)"));

        String[] info = espada.getEquipmentInfo();
        assertEquals("1", info[0]);
        assertEquals("1", info[1]);
        assertEquals("6", info[2]);
        assertEquals("7", info[3]);

        espada.atualizarCoordenadas(8, 9);
        info = espada.getEquipmentInfo();
        assertEquals("8", info[2]);
        assertEquals("9", info[3]);
    }

    @Test
    public void testLixivia2() {
        Lixivia lixivia = new Lixivia(1, 2, 3);

        assertEquals(1.0, lixivia.getCapacidade(), 0.001);

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.7, lixivia.getCapacidade(), 0.001);

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.4, lixivia.getCapacidade(), 0.001);

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.1, lixivia.getCapacidade(), 0.001);

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.0, lixivia.getCapacidade(), 0.001);

        assertFalse(lixivia.usarLixivia());
        assertEquals(0.0, lixivia.getCapacidade(), 0.001);

        Lixivia novaLixivia = new Lixivia(2, 4, 5);
        String infoString = novaLixivia.getEquipmentInfoAsString();
        assertTrue(infoString.contains("Lixívia"));
        assertTrue(infoString.contains("(4, 5)"));
        assertTrue(infoString.contains("1.0 litros"));

        novaLixivia.usarLixivia();
        infoString = novaLixivia.getEquipmentInfoAsString();
        assertTrue(infoString.contains("0.7 litros"));

        String[] info = novaLixivia.getEquipmentInfo();
        assertEquals("2", info[0]);
        assertEquals("3", info[1]);
        assertEquals("4", info[2]);
        assertEquals("5", info[3]);

        novaLixivia.atualizarCoordenadas(6, 7);
        assertEquals(6, novaLixivia.getX());
        assertEquals(7, novaLixivia.getY());
    }

    @Test
    public void testLixiviaEdgeCases() {
        Lixivia lixivia = new Lixivia(1, 2, 3);

        assertEquals(1.0, lixivia.getCapacidade(), 0.001);

        for (int i = 0; i < 3; i++) {
            assertTrue(lixivia.usarLixivia());
            double expectedCapacity = 1.0 - ((i + 1) * 0.3);
            assertEquals(expectedCapacity, lixivia.getCapacidade(), 0.001);
        }

        assertTrue(lixivia.usarLixivia());
        assertEquals(0.0, lixivia.getCapacidade(), 0.001);

        assertFalse(lixivia.usarLixivia());
        assertEquals(0.0, lixivia.getCapacidade(), 0.001);
    }

    @Test
    public void testOfensivoDefensivo() {

        class TesteOfensivo extends Ofensivo {
            public TesteOfensivo(int id, int tipo, int x, int y) {
                super(id, tipo, x, y);
            }
            @Override
            public String getEquipmentInfoAsString() {
                return "Teste";
            }
        }

        TesteOfensivo ofensivo = new TesteOfensivo(1, 1, 2, 3);
        assertEquals(1, ofensivo.getTipo());
        String[] infoOfensivo = ofensivo.getEquipmentInfo();
        assertEquals("1", infoOfensivo[0]);
        assertEquals("1", infoOfensivo[1]);
        assertEquals("2", infoOfensivo[2]);
        assertEquals("3", infoOfensivo[3]);

        class TesteDefensivo extends Defensivo {
            public TesteDefensivo(int id, int tipo, int x, int y) {
                super(id, tipo, x, y);
            }
            @Override
            public String getEquipmentInfoAsString() {
                return "Teste";
            }
        }

        TesteDefensivo defensivo = new TesteDefensivo(2, 0, 4, 5);
        assertEquals(0, defensivo.getTipo());
        String[] infoDefensivo = defensivo.getEquipmentInfo();
        assertEquals("2", infoDefensivo[0]);
        assertEquals("0", infoDefensivo[1]);
        assertEquals("4", infoDefensivo[2]);
        assertEquals("5", infoDefensivo[3]);
    }

    @Test
    public void testGameManagerAdvanced() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        File testFile = new File("test-files/test1.txt");
        manager.loadGame(testFile);

        assertEquals(10, manager.getCurrentTeamId());
        manager.move(3, 3, 3, 2);
        assertEquals(20, manager.getCurrentTeamId());
        manager.move(3, 4, 3, 5);
        assertEquals(10, manager.getCurrentTeamId());

        String[] equipInfo = manager.getEquipmentInfo(-1);
        assertNotNull(equipInfo);
        String equipInfoString = manager.getEquipmentInfoAsString(-1);
        assertNotNull(equipInfoString);

        assertNull(manager.getEquipmentInfo(999));
        assertNull(manager.getEquipmentInfoAsString(999));

        assertNull(manager.getCreatureInfo(999));
        assertNull(manager.getCreatureInfoAsString(999));

        assertNull(manager.getSquareInfo(-1, -1));
        assertNull(manager.getSquareInfo(100, 100));

        assertFalse(manager.hasEquipment(999, 1));

        assertFalse(manager.move(-1, -1, 0, 0));
        assertFalse(manager.move(100, 100, 0, 0));

        String squareInfo = manager.getSquareInfo(0, 0);
        assertNotNull(squareInfo);
    }

    @Test
    public void testZombieDetailedBehaviors() {
        Tabuleiro tab = new Tabuleiro(10, 10);

        ZombieCrianca zCrianca = new ZombieCrianca(1, 10, "TestZC", 2, 2);
        assertTrue(zCrianca.podeMoverPara(2, 2, 2, 3, tab));
        assertFalse(zCrianca.podeMoverPara(2, 2, 2, 4, tab));
        assertFalse(zCrianca.podeMoverPara(2, 2, 3, 3, tab));

        String infoCrianca = zCrianca.getCreatureInfoAsString();
        assertTrue(infoCrianca.contains("Criança"));
        assertTrue(infoCrianca.contains("TestZC"));

        ZombieAdulto zAdulto = new ZombieAdulto(2, 10, "TestZA", 3, 3);
        assertTrue(zAdulto.podeMoverPara(3, 3, 5, 3, tab));
        assertTrue(zAdulto.podeMoverPara(3, 3, 3, 5, tab));
        assertTrue(zAdulto.podeMoverPara(3, 3, 5, 5, tab));
        assertFalse(zAdulto.podeMoverPara(3, 3, 6, 6, tab));

        zAdulto.setFoiTransformado(true);
        String infoAdulto = zAdulto.getCreatureInfoAsString();
        assertTrue(infoAdulto.contains("Transformado"));

        ZombieIdoso zIdoso = new ZombieIdoso(3, 10, "TestZI", 4, 4);
        for (int x = 3; x <= 5; x++) {
            for (int y = 3; y <= 5; y++) {
                if (x == 4 && y == 4) continue;
                if (Math.abs(x - 4) == 1 && Math.abs(y - 4) == 1) {
                    assertTrue(zIdoso.podeMoverPara(4, 4, x, y, tab));
                } else {
                    assertFalse(zIdoso.podeMoverPara(4, 4, x, y, tab));
                }
            }
        }

        Vampiro vampiro = new Vampiro(4, 10, "TestV", 5, 5);
        assertFalse(vampiro.podeMoverPara(5, 5, 6, 6, tab)); // dia
        tab.incrementarJogada(); // noite
        tab.incrementarJogada();
        assertTrue(vampiro.podeMoverPara(5, 5, 6, 6, tab));

        Posicao origem = new Posicao(2, 2);
        Posicao destino = new Posicao(2, 3);
        destino.setEquipamento(new EscudoMadeira(1, 2, 3));

        zCrianca.executarMovimento(2, 3, origem, destino);
        assertEquals(1, zCrianca.getEquipamentosDestruidos());

        zAdulto.setFoiTransformado(true);
        assertTrue(zAdulto.getCreatureInfoAsString().contains("Transformado"));
        zAdulto.setFoiTransformado(false);
        assertFalse(zAdulto.getCreatureInfoAsString().contains("Transformado"));
    }

    @Test
    public void testVampiroAvancado() {
        Tabuleiro tab = new Tabuleiro(8, 8);
        Vampiro vampiro = new Vampiro(1, 10, "Dracula", 4, 4);

        assertFalse(vampiro.podeMoverPara(4, 4, 6, 5, tab));
        assertFalse(vampiro.podeMoverPara(4, 4, 5, 6, tab));

        assertFalse(vampiro.podeMoverPara(4, 4, 5, 5, tab));

        tab.incrementarJogada();
        tab.incrementarJogada();
        assertTrue(vampiro.podeMoverPara(4, 4, 5, 5, tab)); // noite

        tab.incrementarJogada();
        tab.incrementarJogada();
        assertFalse(vampiro.podeMoverPara(4, 4, 5, 5, tab)); // dia

        for (int i = 0; i < 3; i++) {
            vampiro.incrementarEquipamentosDestruidos();
        }
        String info = vampiro.getCreatureInfoAsString();
        assertTrue(info.contains("-3"));
    }

    @Test
    public void testZombieAdultoAvancado() {
        Tabuleiro tab = new Tabuleiro(10, 10);
        ZombieAdulto zAdulto = new ZombieAdulto(1, 10, "Walker", 5, 5);

        assertTrue(zAdulto.podeMoverPara(5, 5, 7, 5, tab)); // horizontal 2 casas
        assertTrue(zAdulto.podeMoverPara(5, 5, 5, 7, tab)); // vertical 2 casas

        zAdulto.setFoiTransformado(true);
        for (int i = 0; i < 5; i++) {
            zAdulto.incrementarEquipamentosDestruidos();
        }
        String[] info = zAdulto.getCreatureInfo();
        assertTrue(info[2].contains("Transformado"));
        assertTrue(zAdulto.getCreatureInfoAsString().contains("-5"));
    }

    @Test
    public void testZombieIdosoAvancado() {
        Tabuleiro tab = new Tabuleiro(6, 6);
        ZombieIdoso zIdoso = new ZombieIdoso(1, 10, "Elder", 3, 3);

        assertTrue(zIdoso.podeMoverPara(3, 3, 4, 4, tab));  // diagonal inferior direita
        assertTrue(zIdoso.podeMoverPara(3, 3, 2, 4, tab));  // diagonal superior direita
        assertTrue(zIdoso.podeMoverPara(3, 3, 2, 2, tab));  // diagonal superior esquerda
        assertTrue(zIdoso.podeMoverPara(3, 3, 4, 2, tab));  // diagonal inferior esquerda

        assertFalse(zIdoso.podeMoverPara(3, 3, 3, 4, tab));  // vertical
        assertFalse(zIdoso.podeMoverPara(3, 3, 4, 3, tab));  // horizontal

        zIdoso.setFoiTransformado(true);
        for (int i = 0; i < 4; i++) {
            zIdoso.incrementarEquipamentosDestruidos();
        }

        String[] creatureInfo = zIdoso.getCreatureInfo();
        assertTrue(creatureInfo[2].contains("Transformado"));
        String infoString = zIdoso.getCreatureInfoAsString();
        assertTrue(infoString.contains("-4"));
        assertTrue(infoString.contains("Elder"));
        assertEquals("Idoso", zIdoso.getTipoCriatura());
    }

    @Test
    public void testHumanoIdosoAvancado() throws InvalidFileException {
        Tabuleiro tab = new Tabuleiro(7, 7);
        HumanoIdoso idoso = new HumanoIdoso(1, 20, "Elder", 3, 3);

        assertTrue(idoso.podeMoverPara(3, 3, 4, 4, tab));  // dia
        tab.incrementarJogada();// noite
        tab.incrementarJogada();
        assertFalse(idoso.podeMoverPara(3, 3, 4, 4, tab));
        tab.incrementarJogada();// dia novamente
        tab.incrementarJogada();
        assertTrue(idoso.podeMoverPara(3, 3, 4, 4, tab));

        Posicao origem = new Posicao(3, 3);
        Posicao destino = new Posicao(4, 4);
        ArrayList<Equipamento> equipamentos = new ArrayList<>();

        Lixivia lixivia = new Lixivia(1, 4, 4);
        destino.setEquipamento(lixivia);
        equipamentos.add(lixivia);

        assertFalse(idoso.processarEquipamento(lixivia, origem, destino, equipamentos));

        idoso.executarMovimento(4, 4, origem, destino);
        assertEquals(4, idoso.getX());
        assertEquals(4, idoso.getY());
    }

    @Test
    public void testProcessZombieMovements() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        manager.move(3, 4, 4, 4);

        assertFalse(manager.move(3, 3, 6, 0)); // zombie tenta mover para safe haven

        assertTrue(manager.move(3, 3, 4, 3));
        assertFalse(manager.move(5, 3, 4, 3)); // tenta mover para posição com outro zombie

        assertFalse(manager.move(3, 3, 2, 3)); // move para posição com equipamento
    }

    @Test
    public void testZombieHumanoInteraction() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        manager.move(3, 4, 4, 4);

        assertFalse(manager.move(3, 3, 4, 4));
        String[] info = manager.getCreatureInfo(7);
        assertFalse(info[2].contains("Zombie"));

        manager.move(4, 3, 2, 3); // move para pegar escudo
        assertTrue(manager.move(5, 3, 4, 3)); // não transforma por causa do escudo

        manager.move(2, 2, 5, 4); // move para pegar lixívia
        for (int i = 0; i < 4; i++) {
            manager.move(5, 3, 5, 4);
            manager.move(5, 4, 5, 3);
        }

        assertFalse(manager.move(5, 3, 5, 4));
        info = manager.getCreatureInfo(9);
        assertFalse(info[2].contains("Zombie"));
    }

    @Test
    public void testProcessHumanoAttackEdgeCases() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test1.txt"));

        assertFalse(manager.move(3, 4, 3, 3)); // tenta atacar zombie sem equipamento

        manager.move(3, 4, 2, 3); // move para pegar escudo
        assertFalse(manager.move(2, 3, 3, 3)); // tenta atacar com escudo

        manager.move(4, 3, 5, 4); // move para pegar lixívia
        assertFalse(manager.move(5, 4, 5, 3)); // tenta atacar com lixívia
    }

    @Test
    public void testRamboJamesBond() throws InvalidFileException, IOException {
        GameManager manager = new GameManager();
        manager.loadGame(new File("test-files/test4.txt"));

        // Primeiro turno é dos zombies (10)
        assertTrue(manager.move(3, 3, 3, 2));  // move um zombie

        // Agora pode mover James Bond (20)
        assertFalse(manager.move(5, 6, 5, 3));  // movimento vertical 3 casas

        // Turno dos zombies
        assertFalse(manager.move(5, 3, 4, 3));

        // Turno do James Bond
        assertFalse(manager.move(5, 3, 4, 5)); // movimento diagonal (não permitido)

        // Turno dos zombies
        assertFalse(manager.move(4, 5, 4, 4));

        // James Bond pega espada
        assertFalse(manager.move(5, 3, 2, 0));  // move para pegar espada (-2)
        assertFalse(manager.hasEquipment(8, 1)); // verifica se pegou espada

        // Turno dos zombies
        assertFalse(manager.move(4, 4, 4, 3));

        // Teste informações do James Bond
        String[] info = manager.getCreatureInfo(8);
        assertEquals("Rambo", info[1]);
        assertEquals("Humano", info[2]);
        assertEquals("James Bond", info[3]);

        String infoString = manager.getCreatureInfoAsString(8);
        assertTrue(infoString.contains("Rambo"));
        assertTrue(infoString.contains("James Bond"));
        assertFalse(infoString.contains("+1")); // um equipamento acumulado

        // Turno dos zombies
        assertTrue(manager.move(4, 3, 3, 3));

        // James Bond ataca zombie
        assertFalse(manager.move(2, 0, 3, 3)); // ataca zombie com espada

        // Turno dos zombies
        assertTrue(manager.move(0, 1, 0, 2));

        // James Bond vai para safe haven
        assertTrue(manager.move(3, 3, 0, 6)); // move para safe haven
        List<Integer> safeIds = manager.getIdsInSafeHaven();
        assertFalse(safeIds.contains(8));
    }
}
