package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Defensivo;

public class EscudoMadeira extends Defensivo {
    public EscudoMadeira(int id, int x, int y) {
        super(id, 0, x, y);
    }

    @Override
    public String getEquipmentInfoAsString() {
        return getId() + " | Escudo de madeira @ (" + getX() + ", " + getY() + ")";
    }
}