package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo;

import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;

public abstract class Defensivo extends Equipamento {
    public Defensivo(int id, int tipo, int x, int y) {
        super(id, tipo, x, y);
    }

    public boolean getDefensivo(){
        return true;
    }
}
