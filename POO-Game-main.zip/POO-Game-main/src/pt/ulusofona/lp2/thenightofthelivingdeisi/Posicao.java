package pt.ulusofona.lp2.thenightofthelivingdeisi;

import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

public class Posicao {
    private int x;
    private int y;
    private Humano humano;
    private Zombie zombie;
    private Equipamento equipamento;
    private SafeHaven safeHaven;

    public Posicao(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public boolean isPosicaoVazia() {
        return this.humano == null && this.zombie == null && this.equipamento == null;
    }

    public Humano getHumano() {
        return this.humano;
    }

    public void setHumano(Humano humano) {
        this.humano = humano;
    }

    public Zombie getZombie() {return this.zombie;}

    public void setZombie(Zombie zombie) { this.zombie = zombie;}

    public Equipamento getEquipamento() {
        return this.equipamento;
    }

    public void setEquipamento(Equipamento equipamento) {
        this.equipamento = equipamento;
    }

    public String getSquareInfo() {

        if (this.humano != null) {
            return "H:" + this.humano.getId();
        }

        if (this.zombie != null){
            return "Z:" + this.zombie.getId();
        }

        if(this.equipamento != null) {
            return "E:" + this.equipamento.getId();
        }

        if(this.safeHaven != null) {
            return "SH";
        }
        else {
            return "";
        }
    }

    public SafeHaven getSafeHaven() {
        return this.safeHaven;
    }

    public void setSafeHaven(SafeHaven safeHaven) {
        this.safeHaven = safeHaven;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
