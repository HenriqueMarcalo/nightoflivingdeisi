package pt.ulusofona.lp2.thenightofthelivingdeisi.zombies;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

public class ZombieAdulto extends Zombie {
    public ZombieAdulto(int id, int teamId, String nome, int x, int y) {
        super(id, teamId, 1, nome, x, y);
    }

    @Override
    public String getTipoCriatura() {
        return "Adulto";
    }

    @Override
    public boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro) {
        int deltaX = Math.abs(xDestino - xOrigem);
        int deltaY = Math.abs(yDestino - yOrigem);

        if ((deltaX == 0 && deltaY <= 2) || (deltaY == 0 && deltaX <= 2)) {
            return true;
        }

        if (deltaX == deltaY && deltaX <= 2) {
            return true;
        }

        return false;
    }

    @Override
    public String getCreatureInfoAsString() {
        String txt = foiTransformado ? " (Transformado)" : "";
        return getId() + " | Adulto | Zombie" + txt + " | " + getNome() + " | -" + getEquipamentosDestruidos() + " @ (" + getX() + ", " + getY() + ")";
    }
}