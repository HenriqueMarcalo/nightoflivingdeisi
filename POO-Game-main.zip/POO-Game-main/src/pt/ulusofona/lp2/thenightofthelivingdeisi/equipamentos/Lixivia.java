package pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos;

import pt.ulusofona.lp2.thenightofthelivingdeisi.equipamentos.ofensivodefensivo.Defensivo;

public class Lixivia extends Defensivo {
    private double capacidade;
    private int usos;

    public Lixivia(int id, int x, int y) {
        super(id, 3, x, y);
        this.capacidade = 1.0;
        this.usos = 0;
    }

    public double getCapacidade() {
        return capacidade;
    }

    public boolean usarLixivia() {
        if (usos < 3) {  // Primeiros 3 usos
            capacidade = Math.round((capacidade - 0.3) * 10.0) / 10.0;
            usos++;
            return true;
        }

        if (usos == 3 && capacidade > 0.1) {  // 4º uso: se tiver mais que 0.1, reduz para 0.1
            capacidade = 0.1;
            usos++;
            return true;
        }

        if (capacidade == 0.1) {  // Se tem 0.1, reduz para 0.0
            capacidade = 0.0;
            return true;  // Ainda defende neste ataque
        }

        return false;  // Com 0.0 litros, não defende mais e pode ser transformado
    }


    @Override
    public String getEquipmentInfoAsString() {
        return getId() + " | Lixívia @ (" + getX() + ", " + getY() + ") | " + getCapacidade() + " litros";
    }
}