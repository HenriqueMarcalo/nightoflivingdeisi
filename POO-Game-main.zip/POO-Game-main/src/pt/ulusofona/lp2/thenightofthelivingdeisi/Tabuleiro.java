package pt.ulusofona.lp2.thenightofthelivingdeisi;

import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Equipamento;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Humano;
import pt.ulusofona.lp2.thenightofthelivingdeisi.entidade.Zombie;

import java.util.ArrayList;

public class Tabuleiro {
    private int largura;
    private int altura;
    private Posicao[][] posicao;
    private ArrayList<SafeHaven> safeHavens = new ArrayList<>();
    private int numJogadas;
    private int initialTeamId;
    private int turnosSemTransformacao;


    public Tabuleiro(int largura, int altura) {
        this.largura = largura;
        this.altura = altura;
        this.posicao = new Posicao[altura][largura];
        this.numJogadas = 0;
        this.turnosSemTransformacao = 0;


        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                this.posicao[i][j] = new Posicao(i, j);
            }
        }
    }

    public int getLargura() {
        return largura;
    }

    public int getAltura() {
        return altura;
    }

    public Posicao getPosicao(int x, int y) {
        if (!isPosicaoDentroDosLimites(x, y)) {
            return null;
        }
        return posicao[x][y];
    }

    public void adicionarHumano(int x, int y, Humano humano) {
        posicao[x][y].setHumano(humano);
    }

    public void adicionarZombie(int x, int y, Zombie zombie) {
        posicao[x][y].setZombie(zombie);
    }

    public void adicionarEquipamento(int x, int y, Equipamento equipamento) {
        posicao[x][y].setEquipamento(equipamento);
    }

    public void adicionarSafeHaven (int x, int y, SafeHaven safeHaven) {
        safeHavens.add(safeHaven);
        posicao[x][y].setSafeHaven(safeHaven);
    }

    public void setInitialTeamId(int initialTeamId) {
        this.initialTeamId = initialTeamId;
    }

    public int getInitialTeamId() {
        return initialTeamId;
    }

    public boolean isDay() {
        return (numJogadas / 2) % 2 == 0;
    }

    public int getCurrentTeamId() {
        if (numJogadas % 2 == 0) {
            return (initialTeamId == 10) ? 10 : 20;
        }
        return (initialTeamId == 10) ? 20 : 10;
    }

    public void incrementarJogada() {
        numJogadas++;
        turnosSemTransformacao++;
    }

    public int getNumJogadas() {
        return numJogadas;
    }

    public boolean isPosicaoDentroDosLimites(int x, int y) {
        return x >= 0 && x < altura && y >= 0 && y < largura;
    }

    public SafeHaven getSafeHaven(int x, int y) {
        if (isPosicaoDentroDosLimites(x, y)) {
            return posicao[x][y].getSafeHaven();
        }
        return null;
    }

    public void resetTurnosSemTransformacao() {
        turnosSemTransformacao = -1;  // reseta quando há transformação ou morte
    }

    public int getTurnosSemTransformacao() {
        return turnosSemTransformacao;
    }

    public ArrayList<SafeHaven> getSafeHavens() {
        return new ArrayList<>(safeHavens);
    }

}