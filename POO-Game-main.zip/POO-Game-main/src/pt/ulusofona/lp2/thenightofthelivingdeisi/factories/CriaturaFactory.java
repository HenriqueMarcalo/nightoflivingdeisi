package pt.ulusofona.lp2.thenightofthelivingdeisi.factories;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Entidade;
import pt.ulusofona.lp2.thenightofthelivingdeisi.InvalidFileException;
import pt.ulusofona.lp2.thenightofthelivingdeisi.humanos.*;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.Vampiro;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieAdulto;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieCrianca;
import pt.ulusofona.lp2.thenightofthelivingdeisi.zombies.ZombieIdoso;

public class  CriaturaFactory {
    public static Entidade createCreature (int id, int teamId, int tipo, String nome, int x, int y, int linha) throws InvalidFileException {
        if (teamId == 10) {
            return switch (tipo) {
                case 0 -> new ZombieCrianca(id, teamId, nome, x, y);
                case 1 -> new ZombieAdulto(id, teamId, nome, x, y);
                case 2 -> new ZombieIdoso(id, teamId, nome, x, y);
                case 4 -> new Vampiro(id, teamId, nome, x, y);
                default -> throw new InvalidFileException("Tipo de criatura invalido para Zombie", linha);
            };
        } else if (teamId == 20) {
            return switch (tipo) {
                case 0 -> new HumanoCrianca(id, teamId, nome, x, y);
                case 1 -> new HumanoAdulto(id, teamId, nome, x, y);
                case 2 -> new HumanoIdoso(id, teamId, nome, x, y);
                case 3 -> new Cao(id, teamId, nome, x, y);
                case 5 -> new Rambo(id, teamId, nome, x, y);
                default -> throw new InvalidFileException("Tipo de criatura invalido para Humano", linha);
            };
        }
        throw new InvalidFileException("Equipa invalida", linha);
    }
}