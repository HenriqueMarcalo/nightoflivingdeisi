package pt.ulusofona.lp2.thenightofthelivingdeisi.entidade;

import pt.ulusofona.lp2.thenightofthelivingdeisi.Entidade;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Posicao;
import pt.ulusofona.lp2.thenightofthelivingdeisi.Tabuleiro;

public abstract class Zombie extends Entidade {
    private String nome;
    private int teamId;
    private int tipoCriatura;
    private Equipamento equipamento;
    private int equipamentosDestruidos;
    protected boolean foiTransformado;


    public Zombie(int id, int teamId, int tipoCriatura, String nome, int x, int y) {
        super(id, x, y);
        this.teamId = teamId;
        this.tipoCriatura = tipoCriatura;
        this.nome = nome;
        this.equipamento = null;
        this.equipamentosDestruidos = 0;
        this.foiTransformado = false;
    }

    public String getNome() {
        return this.nome;
    }

    public int getTipoZombie() {
        return this.tipoCriatura;
    }

    public void setFoiTransformado(boolean foiTransformado) {
        this.foiTransformado = foiTransformado;
    }

    public abstract String getTipoCriatura();

    public String[] getCreatureInfo() {
        String[] info = new String[7];
        info[0] = String.valueOf(getId());
        info[1] = getTipoCriatura();
        info[2] = "Zombie" + (foiTransformado ? " (Transformado)" : "");
        info[3] = nome;
        info[4] = String.valueOf(getX());
        info[5] = String.valueOf(getY());
        info[6] = determinarImagemPersonalizada();
        return info;
    }

    public abstract String getCreatureInfoAsString();

    public void incrementarEquipamentosDestruidos() {
        equipamentosDestruidos++;
    }

    public int getEquipamentosDestruidos() {
        return equipamentosDestruidos;
    }

    public abstract boolean podeMoverPara(int xOrigem, int yOrigem, int xDestino, int yDestino, Tabuleiro tabuleiro);

    public void executarMovimento(int xD, int yD, Posicao posOrigem, Posicao posDestino) {
        if (posDestino.getEquipamento() != null) {
            incrementarEquipamentosDestruidos();
        }

        posOrigem.setZombie(null);
        posDestino.setZombie(this);
        setX(xD);
        setY(yD);
    }

    private String determinarImagemPersonalizada() {
        switch (getTipoCriatura()) {
            case "Criança":
                return "mike.png";
            case "Adulto":
                return "brand.png";
            case "Idoso":
                return "singed.png";
            case "Vampiro":
                return "vladimir.png";
            default:
                return null;
        }
    }
}
